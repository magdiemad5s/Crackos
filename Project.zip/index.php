<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Crackos(Beta)</title>
<meta name="generator" content="WYSIWYG Web Builder 12 - http://www.wysiwygwebbuilder.com">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="Crackos.css" rel="stylesheet">
<link href="index.css" rel="stylesheet">
<script src="jquery-1.12.4.min.js"></script>
<script src="jquery-ui.min.js"></script>
<script src="wb.parallax.min.js"></script>
<script src="wwb12.min.js"></script>
<script>
$(document).ready(function()
{
   $('#Layer12').parallax();
});
</script>
</head>
<body>
<div id="container">
<div id="Layer1">
<div id="wb_TextArt1">
<img src="images/img0001.png" id="TextArt1" alt="Crackos" title="Crackos"></div>
<div id="wb_Text14">
<span style="color:#000000;font-family:Arial;font-size:13px;">beta</span></div>
</div>
<div id="Layer2">
<div id="Layer3">
<div id="wb_Text1">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Credit card</span></div>
<div id="wb_Text7">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Credit card Validity Checker dead/alive <br>Gate1<br>and generator</span></div>
<input type="submit" id="Button1" onclick="ShowObjectWithEffect('Layer2', 0, 'slideright', 500);ShowObjectWithEffect('Layer6', 0, 'slideleft', 500);ShowObjectWithEffect('Layer11', 1, 'dropup', 500);return false;" name="" value="Go">
<div id="wb_MaterialIcon4">
<div id="MaterialIcon4"><i class="material-icons">&#xe870;</i></div></div>
</div>
<div id="Layer5">
<input type="submit" id="Button3" onclick="ShowObjectWithEffect('Layer2', 0, 'slideright', 500);ShowObjectWithEffect('Layer6', 0, 'slideleft', 500);ShowObjectWithEffect('Layer12', 1, 'dropdown', 500);return false;" name="" value="Go">
<div id="wb_Text9">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Fortnite account checker by TCM<br>need proxy and combo list<br>and skin changer</span></div>
<div id="wb_Text3">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Fortnite</span></div>
<div id="wb_Image1">
<img src="images/fortnite-logo-black-and-white-11530963293ygopexf22l.png" id="Image1" alt=""></div>
</div>
<div id="Layer7">
<div id="wb_Text4">
<span style="color:#000000;font-family:Oswald;font-size:15px;">proxy list</span></div>
<div id="wb_MaterialIcon3">
<div id="MaterialIcon3"><i class="material-icons">&#xe56a;</i></div></div>
<div id="wb_Text10">
<span style="color:#000000;font-family:Oswald;font-size:11px;">proxy server is a server (a computer system or an application) that acts as an intermediary for requests from clients seeking resources from other servers</span></div>
<input type="submit" id="Button4" onclick="ShowObjectWithEffect('Layer2', 0, 'slideright', 500);ShowObjectWithEffect('Layer6', 0, 'slideleft', 500);ShowObjectWithEffect('Layer13', 1, 'dropright', 500);return false;" name="" value="Go">
</div>
</div>
<div id="Layer6">
<div id="wb_Text2">
<span style="color:#000000;font-family:Oswald;font-size:29px;">More soon.....</span></div>
</div>
<div id="Layer10">
<div id="wb_Text13">
<span style="color:#000000;font-family:Arial;font-size:13px;">@magdiemad1 &amp; @gamehacker080</span></div>
</div>
<div id="Layer11">
<input type="submit" id="Button5" onclick="ShowObjectWithEffect('Layer11', 0, 'fade', 500);ShowObjectWithEffect('Layer2', 1, 'slideleft', 500);ShowObjectWithEffect('Layer6', 1, 'fade', 500);return false;" name="" value="Back">
<div id="Layer4">
<div id="wb_Text5">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Credit card</span></div>
<div id="wb_Text6">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Validity Checker dead/alive <br>Gate1</span></div>
<input type="submit" id="Button2" onclick="window.location.href='https://sieuthuthuat.com/check/';return false;" name="" value="Go">
<div id="wb_MaterialIcon1">
<div id="MaterialIcon1"><i class="material-icons">&#xe870;</i></div></div>
</div>
<div id="Layer8">
<div id="wb_Text8">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Credit card</span></div>
<div id="wb_Text11">
<span style="color:#000000;font-family:Oswald;font-size:15px;">Generator using bin</span></div>
<input type="submit" id="Button8" onclick="window.location.href='https://ccgen.co/';return false;" name="" value="Go">
<div id="wb_MaterialIcon2">
<div id="MaterialIcon2"><i class="material-icons">&#xe870;</i></div></div>
</div>
</div>
<div id="Layer12">
<div id="wb_Image2">
<img src="images/fortnite-logo-black-and-white-11530963293ygopexf22l.png" id="Image2" alt=""></div>
<div id="wb_Text12">
<span style="color:#000000;font-family:Oswald;font-size:16px;">account checker by TCM<br>need combo and proxy list</span></div>
<input type="submit" id="Button9" name="" value="SOON">
<input type="submit" id="Button10" onclick="window.location.href='https://www.file-up.org/ga2s1fwxo0rn';return false;" name="" value="Go">
<div id="wb_Image3">
<img src="images/fortnite-logo-black-and-white-11530963293ygopexf22l.png" id="Image3" alt=""></div>
<div id="wb_Text15">
<span style="color:#000000;font-family:Oswald;font-size:16px;">Skin Changer<br>( get rare skins for&nbsp; free )</span></div>
<div id="wb_Line1">
<img src="images/img0002.png" id="Line1" alt=""></div>
<input type="submit" id="Button6" onclick="ShowObjectWithEffect('Layer2', 1, 'slideleft', 500);ShowObjectWithEffect('Layer6', 1, 'fade', 500);ShowObjectWithEffect('Layer11', 0, 'fade', 500);return false;" name="" value="Back">
</div>
<div id="Layer13">
<iframe name="InlineFrame1" id="InlineFrame3" src="https://www.proxy-list.download/"></iframe>
<input type="submit" id="Button7" onclick="ShowObjectWithEffect('Layer11', 0, 'fade', 500);ShowObjectWithEffect('Layer2', 1, 'slideleft', 500);ShowObjectWithEffect('Layer6', 1, 'fade', 500);return false;" name="" value="Back">
</div>
</div>
</body>
</html>